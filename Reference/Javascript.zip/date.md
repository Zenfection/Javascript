# 

## Properties

| Thuộc tính  | Mô tả |
| ----------- | ----- |
| constructor |       |
| prototype   |       |

---

## Method

| Phương thức          | Mô tả | Ví dụ |
| -------------------- | ----- | ----- |
| getDate()            |       |       |
| getDay()             |       |       |
| getFullYear()        |       |       |
| getHours()           |       |       |
| getMilliseconds()    |       |       |
| getMinutes()         |       |       |
| getMonth()           |       |       |
| getSeconds()         |       |       |
| getTime()            |       |       |
| getTimezoneOffset()  |       |       |
| getUTCDate()         |       |       |
| getUTCHours()        |       |       |
| getUTCMilliseconds() |       |       |
| getUTCMinutes()      |       |       |
| getUTCMonth()        |       |       |
| getUTCSeconds()      |       |       |
| now()                |       |       |
| parse()              |       |       |
| setDate()            |       |       |
| setFullYear()        |       |       |
| setHours()           |       |       |
| setMilliseconds()    |       |       |
| setMinutes()         |       |       |
| setMonth()           |       |       |
| setSeconds()         |       |       |
| setTime()            |       |       |
| setUTCDate()         |       |       |
| setUTCFullYear()     |       |       |
| setUTCHours()        |       |       |
| setUTCMilliseconds() |       |       |
| setUTCMinutes()      |       |       |
| setUTCSeconds()      |       |       |
| toDateString()       |       |       |
| toISOString()        |       |       |
| toJSON()             |       |       |
| toLocaleDateString() |       |       |
| toLocaleTimeString() |       |       |
| toLocaleString()     |       |       |
| toString()           |       |       |
| toTimeString()       |       |       |
| toUTCString()        |       |       |
| UTC()                |       |       |
| valueOf()            |       |       |
