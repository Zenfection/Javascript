# Math

## Object Properties

| Property | Description |
| -------- | ----------- |
| E        |             |
| LN2      |             |
| LN10     |             |
| LOG2E    |             |
| LOG10E   |             |
| PI       |             |
| SQRT1_2  |             |
| SQRT2    |             |

---

## Object Methods

| Method       | Description |
| ------------ | ----------- |
| abs(x)       |             |
| acos(x)      |             |
| acosh(x)     |             |
| asin(x)      |             |
| asinh(x)     |             |
| atan(x)      |             |
| atan2(y,x)   |             |
| atanh(x)     |             |
| cbrt(x)      |             |
| ceil(x)      |             |
| clz32(x)     |             |
| cos(x)       |             |
| exp(x)       |             |
| expm1(x)     |             |
| floor(x)     |             |
| fround(x)    |             |
| log(x)       |             |
| log10(x)     |             |
| log1p(x)     |             |
| log2(x)      |             |
| max(x,y...n) |             |
| min(x,y...n) |             |
| pow(x,y)     |             |
| random       |             |
| round()      |             |
| sign(x)      |             |
| sin(x)       |             |
| sinh(x)      |             |
| sqrt(x)      |             |
| tan(x)       |             |
| tanh(x)      |             |
| trunc(x)     |             |


